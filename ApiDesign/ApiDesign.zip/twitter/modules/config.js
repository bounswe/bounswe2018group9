module.exports = {
    consumer_key:         'R9A7jh9o52fKYqhxqvTEYFf5B',
    consumer_secret:      'znGYtjxYW7BpbUXKqORtcPOw1CuuRUPIWqzAHyXFHSkuwMJoTe',
    access_token:         '981260720766627840-j3hUM68Lr2uGt9vgP87yy50K6kzaAOq',
    access_token_secret:  'GldnnA084s7t1pWDLq2XmBaI3eGN5i2rT4322kOFsVzt5'
    //timeout_ms:           60*1000,  // optional HTTP request timeout to apply to all requests.
};