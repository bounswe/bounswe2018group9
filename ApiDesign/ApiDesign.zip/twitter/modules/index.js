module.exports = {
    tweets: require('./tweets'),
    trends: require('./trends')
}

