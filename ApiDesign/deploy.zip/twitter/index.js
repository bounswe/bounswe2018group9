module.exports = {
  modules: require('./modules'),
  router: require('./controllers')
}