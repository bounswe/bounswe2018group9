module.exports = {
    tweets: require('./tweets'),
    trends: require('./trends'),
    followers: require('./followers'),
	account: require('./account')
};

